import asyncio, json, traceback
from amazon import check_amazon
from flipkart import check_flipkart
from telegram_bot import send_alert
from config import CHECK_INTERVAL, PRODUCTS_FILE

async def monitor():
    print("MAIN STARTED", flush=True)
    try:
        await send_alert("✅ Bot Started Successfully","https://railway.app",True)
        print("STARTUP SENT", flush=True)
    except Exception:
        traceback.print_exc()
    while True:
        try:
            with open(PRODUCTS_FILE) as f:
                data=json.load(f)
            print(f"Loaded {len(data.get('products',[]))} products", flush=True)
            for p in data.get("products",[]):
                try:
                    if p.get("store")=="amazon": r=check_amazon(p["url"])
                    elif p.get("store")=="flipkart": r=check_flipkart(p["url"])
                    else: continue
                    print(r, flush=True)
                    if r.get("stock"): await send_alert(r["title"],r["url"],True)
                except Exception:
                    traceback.print_exc()
            await asyncio.sleep(CHECK_INTERVAL)
        except Exception:
            traceback.print_exc(); await asyncio.sleep(30)

if __name__=="__main__": asyncio.run(monitor())